package se.wigellgrp.sj23posu_wigellgrp;

import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sj23PosuWigellGrpApplication {
    public static void main(String[] args) {
        SpringApplication.run(Sj23PosuWigellGrpApplication.class, args);
    }

}
