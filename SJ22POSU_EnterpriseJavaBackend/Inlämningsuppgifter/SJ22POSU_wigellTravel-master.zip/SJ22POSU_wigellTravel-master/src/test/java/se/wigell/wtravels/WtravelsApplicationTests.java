package se.wigell.wtravels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WtravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
