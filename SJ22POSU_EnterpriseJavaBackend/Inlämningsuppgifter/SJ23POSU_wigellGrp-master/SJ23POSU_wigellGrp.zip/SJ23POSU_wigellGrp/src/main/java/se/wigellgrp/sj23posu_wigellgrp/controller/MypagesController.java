package se.wigellgrp.sj23posu_wigellgrp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import se.wigellgrp.sj23posu_wigellgrp.entity.Address;
import se.wigellgrp.sj23posu_wigellgrp.entity.Members;
import se.wigellgrp.sj23posu_wigellgrp.service.MembersService;

import java.util.List;

@RestController
@RequestMapping("/mypages/members")
public class MypagesController {
    private final Logger logger = LoggerFactory.getLogger(MypagesController.class);
    private MembersService membersService;

    @Autowired
    public MypagesController(MembersService membersService){
        this.membersService = membersService;
    }

    @GetMapping
    public List<Members> findAll(){
        return membersService.findAll();
    }

    @PutMapping
    public Members updateMember(@RequestBody Members members){
        logger.info("Add new member: " + members.getId());
        return membersService.save(members);
    }

}
