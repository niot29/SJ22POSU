package se.wigellgrp.sj23posu_wigellgrp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sj23PosuWigellGrpApplicationTests {

    @Test
    void contextLoads() {
    }

}
